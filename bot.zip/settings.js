module.exports = (client) => {
 
  client.settings = {
      "owner": [""],
    'botid': '',
    "botnick": "",
    "botversion": "1.1.3",
    "embedcolor": "",
    "web": "",
    "secret": "",
    "callbackURL": "",
    
}
 } 
  