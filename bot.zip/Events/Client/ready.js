const { Client } = require("discord.js");

module.exports = {
  name: "ready",
//  once: true,
  /**
   * 
   * @param {Client} client 
   */
  execute(client) {
    const { ActivityType } = require('discord.js');  
      setInterval( async () => {
   let am = ""
   if(100 > client.ws.ping) {
     am = "onilne"
   }else if(150 > client.ws.ping) {
     am = "idle"
   }else{
     am = "dnd"
   }
       client.user.setStatus(am);
        client.user.setActivity({
            type: ActivityType.Watching,
            name: `${client.guilds.cache.size} Servers - ${client.guilds.cache.reduce((a, b) => a + b.memberCount, 0).toLocaleString()} Users`,
        });
     }, 15000)
        console.log(`[LOG] ${client.user.tag} is now online!\n[LOG] Bot serving on Ready to serve in ${client.guilds.cache.size} servers\n[LOG] Bot serving ${client.users.cache.size} users`);
    
  },
};