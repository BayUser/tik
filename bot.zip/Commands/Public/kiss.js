const { SlashCommandBuilder } = require('@discordjs/builders');
const { EmbedBuilder, SelectMenuBuilder } = require("discord.js");
const {ActionRowBuilder, ButtonBuilder} = require("discord.js") 
const moment = require("moment");
const coolpics = require("cool-pics"); 

module.exports = {
   category: "user",
 
    cooldown: 4,
    data: new SlashCommandBuilder()
        .setName('kiss')
        .setDescription('Kiss Someone')
        .addUserOption(option =>
            option.setName('user').setRequired(true).setDescription('User to Kiss.')
        ),

    async execute(interaction, client) {

         const mentionedMember = interaction.options.getMember('user')
 const huggif = coolpics.kiss(); 
         
         let embed = new EmbedBuilder()
    .setImage(huggif)
    .setColor(`${client.settings.embedcolor}`)
    .setTitle(`<a:yay:903369217242451978> | ${interaction.user.username} Kiss ${mentionedMember.user.username}`)
    .setTimestamp()
interaction.reply({embeds: [embed]});    

     
      }
  }

